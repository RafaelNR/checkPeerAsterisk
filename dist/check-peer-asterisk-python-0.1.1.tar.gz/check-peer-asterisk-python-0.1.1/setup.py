# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src', 'src.functions', 'src.helper']

package_data = \
{'': ['*']}

install_requires = \
['DateTime>=5.5,<6.0',
 'argparse>=1.4.0,<2.0.0',
 'openpyxl>=3.1.5,<4.0.0',
 'pandas>=2.2.2,<3.0.0']

entry_points = \
{'console_scripts': ['check_peer = src.__init__:init',
                     'start = src.__init__:init']}

setup_kwargs = {
    'name': 'check-peer-asterisk-python',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'Rafael',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
